#!/usr/bin/env python3
# Created by xiazeng on 2019-05-22
import json
import logging

logger = logging.getLogger()


default_config = {
    "platform": "ide",
    "debug_mode": "info",
    "close_ide": False,  # 是否关闭IDE
    "no_assert_capture": False,
    "device_desire": {},
}


def get_log_level(debug_mode):
    return {
        "info": logging.INFO,
        "debug": logging.DEBUG,
        "warn": logging.WARNING,
        "error": logging.ERROR,
    }.get(debug_mode, logging.INFO)


class MiniConfig(dict):
    def __init__(self, from_dict=None):
        for k, v in default_config.items():
            setattr(self, k, v)
        if from_dict is None:
            self.is_default_config = True
        else:
            self.is_default_config = False
            for k, v in from_dict.items():
                setattr(self, k, v)
        super(MiniConfig, self).__init__(self.__dict__)

    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError:
            return None

    def __setattr__(self, key, value):
        self[key] = value

    @classmethod
    def from_file(cls, filename):
        f = open(filename, "rb")
        json_dict = json.load(f)
        f.close()
        return MiniConfig(json_dict)


if __name__ == "__main__":
    a = MiniConfig({"outputs": "xxxx"})
    print(a.outputs)
    print(a.sss)
