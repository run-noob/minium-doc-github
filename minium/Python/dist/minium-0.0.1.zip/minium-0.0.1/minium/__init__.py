#!/usr/bin/env python3
# Created by xiazeng on 2019-06-24
from .core.minium import Minium, build_version
from .core.page import Page
from .core.app import App
from .core.element import BaseElement
from .framework.minitest import MiniTest

__version__ = "0.0.1"
