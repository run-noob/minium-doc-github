#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from.minium_object import MiniumObject,timeout
import time
from.prefixer import*
class BaseElement(MiniumObject):
 def __init__(self,element_id,page_id,tag_name,connection):
  super().__init__()
  self.element_id=element_id
  self.page_id=page_id
  self._tag_name=tag_name
  self.connection=connection
 def tap(self):
  self._send("Element.tap")
 def click(self):
  self._send("Element.tap")
  time.sleep(1)
 def long_press(self,duration=350):
  self.touch_start()
  time.sleep(duration/1000)
  self.touch_end()
 def touch_start(self):
  self._send("Element.touchstart")
 def touch_end(self):
  self._send("Element.touchend")
 def touch_move(self):
  self._send("Element.touchmove")
 def touch_cancel(self):
  self._send("Element.touchcancel")
 def slide(self,direction,distance):
  raise NotImplementedError()
 def get_element(self,selector,inner_text=None,value=None,text_contains=None,max_timeout=10):
  @timeout(max_timeout)
  def _f():
   elements=self.get_elements(selector,max_timeout)
   if not elements:
    return True
   for element in elements:
    if inner_text and element.inner_text!=inner_text:
     continue
    if value and element.value()!=value:
     continue
    if text_contains and text_contains not in element.inner_text:
     continue
    return element
   return False
  try:
   r=_f()
   if r is True:
    return None
   else:
    return r
  except:
   return None
 def get_elements(self,selector,max_timeout=10):
  elements=[]
  @timeout(max_timeout)
  def refresh_elements():
   ret=self._send("Element.getElements",{"selector":selector})
   if hasattr(ret,"error"):
    raise Exception("Element not found with selector: [%s], cause: %s"%(selector,ret.error))
   for el in ret.result.elements:
    element=BaseElement(el.elementId,self.page_id,el.tagName,self.connection)
    elements.append(element)
   return elements
  try:
   self.logger.info("try to find elements: %s"%selector)
   refresh_elements()
   self.logger.info("find elements success: %s"%str(elements))
   return elements
  except Exception as e:
   self.logger.exception("elements search fail cause: "+str(e))
   return[]
 def attribute(self,name):
  return self._getter("getAttributes","attributes",name)
 @property
 def size(self):
  size_arr=self._dom_property(["offsetWidth","offsetHeight"])
  return{"width":size_arr[0],"height":size_arr[1]}
 def offset(self):
  offset_arr=self._dom_property(["offsetLeft","offsetTop"])
  return{"x":offset_arr[0],"y":offset_arr[1]}
 @property
 def rect(self):
  rect_arr=self._dom_property(["offsetLeft","offsetTop","offsetWidth","offsetHeight"])
  return{"x":rect_arr[0],"y":rect_arr[1],"width":rect_arr[2],"height":rect_arr[3],}
 def styles(self,names):
  return self._getter("getStyles","styles",names)
 @property
 def value(self):
  return self._property("value")[0]
 @property
 def inner_text(self):
  return self._dom_property("innerText")[0]
 @property
 def inner_wxml(self):
  return self._send("Element.getWXML",{"type":"inner"}).result.wxml
 @property
 def outer_wxml(self):
  return self._send("Element.getWXML",{"type":"outer"}).result.wxml
 def _property(self,name):
  return self._getter("getProperties","properties",name)
 def _dom_property(self,name):
  return self._getter("getDOMProperties","properties",name)
 def handle_picker(self,value):
  self.trigger("change",{"value":value})
 def trigger(self,trigger_type,detail):
  params={}
  params["type"]=trigger_type
  if detail:
   params["detail"]=detail
  return self._send("Element.triggerEvent",params)
 def _getter(self,method,return_name,names=""):
  if isinstance(names,list):
   result=self._send("Element."+method,{"names":names})
  elif isinstance(names,str):
   result=self._send("Element."+method,{"names":[names]})
  else:
   raise Exception("invalid names type")
  ret=getattr(result.result,return_name)
  return ret
 def _send(self,method,params=None):
  if params is None:
   params={}
  params["elementId"]=self.element_id
  params["pageId"]=self.page_id
  return self.connection.send(method,params)
class FormElement(BaseElement):
 def __init__(self):
  super().__init__()
 def set_value(self,value):
  pass
 def get_value(self):
  pass
 def clear(self):
  pass
 def submit(self):
  pass
class MediaElement(BaseElement):
 def __init__(self):
  super().__init__()
  self.controller=MediaController()
  self.media_type=MediaType.UNKNOW
 def get_controller(self):
  return self.controller
 def get_media_type(self):
  return self.media_type
 def get_status(self):
  pass
class VideoElement(MediaElement):
 def __init__(self):
  super().__init__()
  self.controller=VideoController()
  self.media_type=MediaType.VIDEO
class AudioElement(MediaElement):
 def __init__(self):
  super().__init__()
  self.controller=AudioController()
  self.media_type=MediaType.AUDIO
class LivePlayElement(MediaElement):
 def __init__(self):
  super().__init__()
  self.controller=LiveController()
  self.media_type=MediaType.LIVE_PLAY
class LivePushElement(MediaElement):
 def __init__(self):
  super().__init__()
  self.controller=LiveController()
  self.media_type=MediaType.LIVE_PUSH
class MediaController(object):
 def __init__(self):
  pass
 def play(self):
  pass
 def pause(self):
  pass
 def stop(self):
  pass
 def seek(self,time):
  pass
class VideoController(MediaController):
 def __init__(self):
  super().__init__()
 def full_screen(self):
  pass
 def get_video_info(self):
  pass
class AudioController(MediaController):
 def __init__(self):
  super().__init__()
 def get_audio_info(self):
  pass
class LiveController(MediaController):
 def __init__(self):
  super().__init__()
 def get_debug_info(self):
  pass
# Created by pyminifier (https://github.com/liftoff/pyminifier)
