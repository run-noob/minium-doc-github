#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import time
from.page import Page
from.minium_object import MiniumObject,timeout
import os
import threading
cur_path=os.path.dirname(os.path.realpath(__file__)) 
conf_path=os.path.join(os.path.dirname(cur_path),"conf/iOS_conf")
class App(MiniumObject):
 def __init__(self,connection):
  super().__init__()
  self.connection=connection
  self._msg_lock=threading.Condition()
  self.route_is_changed=False
  self.main_page_path="/"+self._get_launch_options_sync().result.result.path
  self.current_path_path=self.main_page_path
  self.current_page_id=self._current_page().page_id
  self.expose_function("onAppRouteDone",self._on_route_changed)
  self.evaluate("function() {wx.onAppRouteDone(function(options) {onAppRouteDone(options)})}")
 def enable_log(self):
  self.connection.send("App.enableLog")
 def exit(self):
  self.connection.send("App.exit")
 def evaluate(self,app_function:str,args=None):
  if not args:
   args=[]
  return self.connection.send("App.callFunction",{"functionDeclaration":app_function,"args":args})
 def expose_function(self,name,binding_function):
  self.connection.register("App.bindingCalled",binding_function)
  self.connection.send("App.addBinding",{"name":name})
 def get_current_page(self)->Page:
  return self._current_page()
 def _current_page(self):
  ret=self.connection.send("App.getCurrentPage")
  if hasattr(ret,"error"):
   raise Exception("Get current page fail, cause: %s"%ret.error)
  page=Page(ret.result.pageId,"/"+ret.result.path,ret.result.query,self.connection)
  self.current_path_path=page.path
  self.current_page_id=page.page_id
  return page
 def get_page_stack(self):
  ret=self.connection.send("App.getPageStack")
  page_stack=[]
  for page in ret.result.pageStack:
   page_stack.append(Page(page.pageId,page.path,page.query,self.connection))
  return page_stack
 def go_home(self):
  page=(self.relaunch(self.main_page_path)if self.main_page_path!="/" else self.relaunch("/"+self._get_launch_options_sync().result.result.path))
  return page
 def _get_launch_options_sync(self):
  return self.call_wx_method("getLaunchOptionsSync")
 def _change_route(self,open_type,path,is_wait_url_change=True):
  before_path=self._current_page().path
  self.call_wx_method(open_type,[{"url":path}])
  if path.startswith(before_path):
   self.logger.warning("Current page is already %s"%path)
   return self._current_page()
  if self._route_changed():
   return self._current_page()
  else:
   raise Exception("%s %s Fail"%(open_type,path))
 def _on_route_changed(self,message):
  self.route_is_changed=True
  self._msg_lock.acquire()
  self._msg_lock.notify()
  self._msg_lock.release()
  self.logger.info("Route changed, %s"%message)
 def navigate_to(self,url,params=None,is_wait_url_change=True):
  if params:
   url+="?"+"&".join(["%s=%s"%(k,v)for k,v in params.items()])
  self.logger.info("NavigateTo: %s"%url)
  page=self._change_route("navigateTo",url,is_wait_url_change)
  if page.path!=url:
   self.logger.warning("NavigateTo(%s) fail ! Current page has not change"%url)
  return page
 def redirect_to(self,url):
  wait=False if url==self.get_current_page()else True
  self.logger.info("RedirectTo: %s"%url)
  page=self._change_route("redirectTo",url,wait)
  if page.path!=url:
   self.logger.warning("RedirectTo(%s) fail ! Current page has not change"%url)
  return page
 def relaunch(self,url):
  self.logger.info("ReLaunch: %s"%url)
  page=self._change_route("reLaunch",url)
  if page.path!=url:
   self.logger.warning("ReLaunch(%s) fail ! Current page has not change"%url)
  time.sleep(1)
  return page
 def navigate_back(self,delta=1):
  self._wait_until_page_is_stable()
  page=self._current_page()
  page_stack=self.get_page_stack()
  if page.page_id==page_stack[0].page_id:
   self.logger.warning("Current page is root, can't navigate back")
   return page
  self.logger.info("NavigateBack from:%s"%page.path)
  self.call_wx_method("navigateBack",[{"delta":delta}])
  if self._route_changed():
   return self._current_page()
  else:
   self.logger.warning("route has not change, may be navigate back fail")
 def switch_tab(self,url):
  page=self._change_route("switchTab",url)
  if page.path!=url:
   self.logger.warning("Switch tab(%s) fail ! Current page has not change"%url)
  return page
 @timeout(10)
 def _wait_until_page_is_stable(self):
  return True if self.current_page_id==self._current_page().page_id else False
 @timeout(10)
 def _wait_until_page_is_change(self):
  return True if self.current_page_id!=self._current_page().page_id else False
 def _route_changed(self,timeout=None):
  if not timeout:
   timeout=10
  self._msg_lock.acquire()
  self._msg_lock.wait(timeout)
  self._msg_lock.release()
  if self.route_is_changed:
   self.route_is_changed=False
   return True
  else:
   self.route_is_changed=False
   return False
# Created by pyminifier (https://github.com/liftoff/pyminifier)
