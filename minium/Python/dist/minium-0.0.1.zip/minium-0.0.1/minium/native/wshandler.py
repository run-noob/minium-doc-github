#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by xiazeng on 2019-04-25
import logging
import json
import minium.native
import tornado.websocket
import traceback

logger = logging.getLogger()


class WsErrorCode(object):
    SUCCESS = 0
    ERROR_UNKNOWN = -100000
    ERROR_AT_INIT = -100001
    ERROR_METHOD_NOT_IMPLEMENTATION = -200001

    @classmethod
    def msg(cls, ret):
        return {
            cls.SUCCESS: "success",
            cls.ERROR_AT_INIT: "at init failed",
            cls.ERROR_METHOD_NOT_IMPLEMENTATION: "method not implementation",
            cls.ERROR_UNKNOWN: "not define error",
        }.get(ret, "unknown error")


class WsReq(object):
    def __init__(self, message):
        cmd = json.loads(message)
        self.args = cmd["params"]["args"]
        self.kwargs = cmd["params"]["kwargs"]
        self.method = cmd["method"]
        self.id = cmd["id"]

    def to_dict(self, result, ret=WsErrorCode.SUCCESS):
        return {
            "id": self.id,
            "result": result,
            "error": WsErrorCode.msg(ret),
            "error_code": ret,
        }


class WsHandler(tornado.websocket.WebSocketHandler):
    def initialize(self):
        self.native = None

    def is_connection(self):
        return self.ws_connection is not None

    def send_event(self, method, params):
        self.write_message({"method": method, "params": params})

    def write_res(self, req, result=None, rtn=WsErrorCode.SUCCESS):
        self.write_message(req.to_dict(result, rtn))

    def on_message(self, message):
        logger.debug(message)
        req = WsReq(message)
        try:
            if req.method == "create":
                self.native = minium.native.get_native_driver(self.os_type, req.kwargs)
                self.write_res(req)
            assert self.native is not None
            method_imp = getattr(self.native, req.method, None)
            if method_imp is None:
                self.write_res(
                    req,
                    "%s not exists" % req.method,
                    WsErrorCode.ERROR_METHOD_NOT_IMPLEMENTATION,
                )
                return
            result = method_imp(*req.args, **req.kwargs)
            self.write_res(req, result)
        except tornado.websocket.WebSocketClosedError:
            logger.warning("connection has closed")
        except:
            traceback.print_exc()
            self.write_res(req, traceback.format_exc(), WsErrorCode.ERROR_UNKNOWN)

    def on_close(self):
        logger.info("on_close")
        method_imp = getattr(self.native, "release", None)
        method_imp()

    def on_ping(self, data):
        logger.warning("on_ping")

    def open(self, os_type):
        self.os_type = os_type
        logger.info("opened from:%s", self.request.remote_ip)
        self.send_event("opened", "opened success")
