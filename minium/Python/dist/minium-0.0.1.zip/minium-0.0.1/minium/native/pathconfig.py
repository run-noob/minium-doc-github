#!/usr/bin/env python3
# Created by xiazeng on 2019-05-22
import sys
import os.path

work_root = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, work_root)
lib_path = os.path.join(work_root, "lib")
sys.path.insert(0, lib_path)
